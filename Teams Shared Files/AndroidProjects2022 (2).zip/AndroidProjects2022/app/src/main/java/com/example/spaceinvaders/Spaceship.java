package com.example.spaceinvaders;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

public class Spaceship {
    //canvas drawing
    // RectF is an object that holds four coordinates
    RectF rect;

    // How long and high the spaceship will be
    private float height;
    private float length;

    // x and y coords of the ship - X is the far left of the rectangle and y is the top coordinate
    private float x;
    private float y;

    // speed- holds the pixels per second that the spaceship will move
    private int spaceShipSpeed;

    // The spaceship will be represented by a Bitmap
    private Bitmap bitmapup;
    private Bitmap bitmapleft;
    private Bitmap bitmapright;
    private Bitmap bitmapdown;
    public Bitmap currentBitmap;

    // Directions spaceship can move
    public final int STOPPED = 0;
    public final int LEFT = 1;
    public final int RIGHT = 2;
    public final int UP = 3;
    public final int DOWN = 4;

    // Is the ship moving and in which direction
    private int SpaceShipMoving = STOPPED;

    private int screenX;
    private int screenY;
    //    private float SpaceShipSpeed;


    // Spaceship constructor -When we initialise an object of the type Spaceship we need to pass in values that match those in the
    // signature. In this case, two int variables, screenX and screenY with  horizontal and vertical resolution of pixels
    public Spaceship(Context context, int screenX, int screenY) {

        // Ship size - We initialise length and height by dividing the screen resolution on the
        // horizontal and vertical axes by ten. Ten is an arbitrary value but it works well.
        // For a smaller ship, increase the number for a bigger ship decrease the number.
        length = screenX / 10;
        height = screenY / 10;

        //initialize x and y to the middle of the screen horizontally and just above the bottom vertically
        x = screenX / 2;
        y = screenY / 2;

        rect = new RectF();

        // speed of the spaceship (pixels per second)
        spaceShipSpeed = 350;

        //LOAD bitmaps with the spaceshipup.png file using BitmapFactory.decodeResource and after that,
        // we scale bitmap to the correct length and height using Bitmap.createScaledBitmap method.
        bitmapup = BitmapFactory.decodeResource(context.getResources(), R.drawable.spaceshipup);
        // stretch the bitmap to a size appropriate for the screen resolution
        bitmapup = Bitmap.createScaledBitmap(bitmapup, (int) (length), (int) (height), false);

        bitmapright = BitmapFactory.decodeResource(context.getResources(), R.drawable.spaceshipright);
        bitmapright = Bitmap.createScaledBitmap(bitmapright, (int) (length), (int) (height), false);

        bitmapleft = BitmapFactory.decodeResource(context.getResources(), R.drawable.spaceshipleft);
        bitmapleft = Bitmap.createScaledBitmap(bitmapleft, (int) (length), (int) (height), false);

        bitmapdown = BitmapFactory.decodeResource(context.getResources(), R.drawable.spaceshipdown);
        bitmapdown = Bitmap.createScaledBitmap(bitmapdown, (int) (length), (int) (height), false);

        currentBitmap = bitmapleft;
        this.screenX = screenX;
        this.screenY = screenY;
    } //  end Spaceship constructor

    //method setMovementState in state eg 0 1 2 3 4 including stop state
    // This method will be used to change/set if the ship is going left, up, top, down or nowhere
    public void setMovementState(int state) {

        SpaceShipMoving = state;
    }

    //rect for collision detection,
    public RectF getRect() {
        return rect;
    }

    //bitmap for drawing the spaceship
    public Bitmap getBitmap() {
        return currentBitmap;
    }

    //Accessing private variables with getters and setters
    //x and length for firing bullets from the centre of the ship
    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getLength() {
        return length;
    }

    public float getHeight() {
        return height;
    }

    //The update method of the Spaceship class is separate from the update method of our SpaceGameView class.
    // Once per frame, the update method of the SpaceGameView class will call the update method of the Spaceship class.
    // In this update method, the Spaceship will be assigned new coordinates if required, ready for when the draw method is called.

    //In the update method, we check for four  possible conditions spaceShioMoving == LEFT, RIGHT, UP and DOWN.
    // Then change the x coordinate by the speed per second divided by the frames per second passed into the method.
    // After the four if statements we update the starting and finishing ( rect.left and rect.right) coordinates of rect.
    // Notice that if paddleMoving == STOPPED is true then nothing would change that frame.
    public void update(long fps) {
        if (SpaceShipMoving == LEFT) {
            x = x - spaceShipSpeed / fps;
            currentBitmap = bitmapleft; //set the correct bitmap
            if ((x + length) <= 0)
                x = screenX;
        }
        if (SpaceShipMoving == RIGHT) {
            x = x + spaceShipSpeed / fps;
            currentBitmap = bitmapright;
            if (x >= screenX)
                x = 0 - length;
        }
        if (SpaceShipMoving == UP) {
            y = y - spaceShipSpeed / fps;
            currentBitmap = bitmapup;
            if (y + height <= 0)
                y = screenY;
        }

        if (SpaceShipMoving == DOWN) {
            y = y + spaceShipSpeed / fps;
            currentBitmap = bitmapdown;
            if (y >= screenY)
                y = 0 - height;
        }
        //We know the ending locations simply by adding height to y and length to x
        // Update rect which is used to detect hits
        rect.top = y;
        rect.bottom = y + height;
        rect.left = x;
        rect.right = x + length;

    }

} //end the class spaceship