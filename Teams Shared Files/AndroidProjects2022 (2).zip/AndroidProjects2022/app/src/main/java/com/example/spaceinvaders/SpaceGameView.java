package com.example.spaceinvaders;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.SoundPool;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.IOException;

// This is  the implementation of SpaceGameView
// class declaration needs to be modified to extend SurfaceView and
// implement Runnable to provide our drawing and threading and override the run method.
class SpaceGameView extends SurfaceView implements Runnable {

    private Context context;

    // Our thread
    private Thread gameThread = null;

    // We need a SurfaceHolder when we use Paint and Canvas in a thread
    //will see it in action in the draw method soon.
    private SurfaceHolder myHolder;

    // A boolean which we will set and unset when the game is running- or not.
    //Accessing a volatile variable synchronises all the cached copy of the variables in the main memory.
    // Volatile can only be applied to instance variables, which are of type object or private. A volatile object reference can be null.
    private volatile boolean playing;

    // at the start the g
    // ame is paused
    private boolean paused = true;

    // A Canvas and a Paint object
    private Canvas canvas;
    private Paint paint;

    // fps - tracks the game frame rate (frames per second)
    private long fps;

    // Used for  calculating the fps
    private long timeThisFrame;

    // The size of the screen in pixels
    private int screenX;
    private int screenY;

    // The score
    private int score = 0;

    // Lives
    private int lives = 5;

    //declare spaceShip, bullet and bitmap objects
    private Spaceship spaceShip;
    private Bullet bullet;
    private Bitmap bitmapback;

    // The invaders bullets (18 invaders 6 in a row)
    private Bullet[] invadersBullets = new Bullet[180];
    private int nextBullet;
    //max bullets per invador
    private int maxInvaderBullets = 10;


    // declare an array to hold Invader objects 18 invaders
    private Invader[] invaders = new Invader[18];
    private int numInvaders = 0;

    // how menacing should the sound be
    private long menaceInterval = 1000;

    // For sounds
    private SoundPool soundPool;
    private int playerExplodeID = -1;
    private int invaderExplodeID = -1;
    private int shootID = -1;
    private int uhID = -1;
    private int ohID = -1;

    // Which menace sound should play next
    private boolean uhOrOh;
    // When did we last play a menacing sound
    private long lastMenaceTime = System.currentTimeMillis();


    // This special constructor method runs
    //The constructor is the method called from MainActivity
    // spaceGameView = new SpaceGameView(this, screenX, screenY).
    //  is the signature of the method which receives the variables passed in.
    // When we initialise (call new()) on spaceGameView
    // This special constructor method runs
    public    SpaceGameView(Context context, int x, int y) {

        // Constructors are not inherited, even though they have public visibility
        // if to call the parent class ( SurfaceView) to help set the object
        // with the code super(context)
        super(context);

        // Make a globally available copy of the context so we can use it in another method
        this.context = context;

        // Initialise myHolder and paint objects
        myHolder = getHolder();
        paint = new Paint();

        screenX = x;
        screenY = y;

        // This SoundPool is deprecated - used in a try catch block
        soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);

        try {
            // Create objects of the 2 required classes
            AssetManager assetManager = context.getAssets();
            AssetFileDescriptor descriptor;

            // Load our fx in memory ready for use
            descriptor = assetManager.openFd("shoot.ogg");
            shootID = soundPool.load(descriptor, 0);

            descriptor = assetManager.openFd("invaderexplode.ogg");
            invaderExplodeID = soundPool.load(descriptor, 0);

            descriptor = assetManager.openFd("playerexplode.ogg");
            playerExplodeID = soundPool.load(descriptor, 0);

            descriptor = assetManager.openFd("uh.ogg");
            uhID = soundPool.load(descriptor, 0);

            descriptor = assetManager.openFd("oh.ogg");
            ohID = soundPool.load(descriptor, 0);

        } catch (IOException e) {
            // Print an error message to the console
            Log.e("error", "failed to load sound files");
        }

        initLevel();
    }


    // Here in the constructor we call the initLevel method -
    // initialise all our game objects and get ready to play the game
    // create a new instance of the spaceship pass the sizes by invoking the constructor method of the spaceship class
    private void initLevel() {
        // Reset the menace level
        menaceInterval = 1000;

        // instantiate - make a new  spaceship, pass in the screen’s horizontal and vertical resolution
        spaceShip = new Spaceship(context, screenX, screenY);

        // instantiate  the  bullet
        bullet = new Bullet(screenY, screenX);

        // Create an array of invaders
        numInvaders = 0;
        for (int column = 0; column < 6; column++)
            for (int row = 0; row < 3; row++) {
                invaders[numInvaders] = new Invader(context, row, column, screenX, screenY);
                numInvaders++;
            }

        // Initialize the invadersBullets array
        for (int i = 0; i < invadersBullets.length; i++) {
            invadersBullets[i] = new Bullet(screenY, screenX);
        }

    } //enf of initLevel()

    //run())- constantly calls update and draw while keeping track of the fps
    @Override
    public void run() {
        while (playing) {
//            score = 0;
            // Capture the current time in milliseconds in startFrameTime
            long startFrameTime = System.currentTimeMillis();

            // if(!paused) - player can start the game with a touch of the screen
            if (!paused) {
                update();
            }
            // Draw the frame
            draw();
            // Calculate the fps this frame, then use the result to
            // time animations and more. changed 1000 to 500
            timeThisFrame = System.currentTimeMillis() - startFrameTime;
            if (timeThisFrame >= 1) {
                fps = 1000 / timeThisFrame;
            }
            // play a sound based on the menace level
            if (!paused) {
                if ((startFrameTime - lastMenaceTime) > menaceInterval) {
                    if (uhOrOh) soundPool.play(uhID, 1, 1, 0, 0, 1);
                    else soundPool.play(ohID, 1, 1, 0, 0, 1);
                    // reset the last menace time
                    lastMenaceTime = System.currentTimeMillis();
                    // flip value of uhOrOh
                    uhOrOh = !uhOrOh;
                }
            }

            // Within the while loop - Play a sound based on the menace level
            if(!paused) {
                if ((startFrameTime - lastMenaceTime) > menaceInterval) {
                    if (uhOrOh) {
                        // Play Uh
                        soundPool.play(uhID, 1, 1, 0, 0, 1);

                    } else {
                        // Play Oh
                        soundPool.play(ohID, 1, 1, 0, 0, 1);
                    }

                    // Reset the last menace time
                    lastMenaceTime = System.currentTimeMillis();
                    // Alter value of uhOrOh
                    uhOrOh = !uhOrOh;
                }
            }

        }

    } //end of run() method


    // Everything that needs to be updated goes in here
    // Movement, collision detection etc.
    private void update() {

        // Move the spaceship if required
        spaceShip.update(fps);

        // Update the spaceship bullet
        if (bullet.getStatus())
            bullet.update(fps);

        // checkCollisions
        checkCollisions();


        // Did an invader bump into the side of the screen
        boolean bumped = false;

        // Has the player lost
        boolean lost = false;

        // Move the player's ship
        // Update all the invaders if visible
        for (int i = 0; i < numInvaders; i++) {
            //loop through each and every invader and check if it is visible.
            if (invaders[i].getVisibility()) {
                // If it is we call its update method and its coordinates will be updated
                invaders[i].update(fps);

                // call takeAim on each and every invader in the array. Using the odds and aiming criteria specified in the
                // takeAim method it might or might not return true.
                if (invaders[i].takeAim(spaceShip.getX(),
                        spaceShip.getLength())) {

                    //  If it returns true we call shoot on the next bullet in the array as identified by nextBullet.
                    if (invadersBullets[nextBullet].shoot(invaders[i].getX() +
                                    invaders[i].getLength() / 2,
                            invaders[i].getY(), bullet.DOWN)) {

                        // If a bullet is successfully fired nextBullet is incremented ready for the next invader
                        nextBullet++;

                        // check if nextBullet is equal to maxInvaderBullets and if it is we set nextBullet back to zero
                        if (nextBullet == maxInvaderBullets) {
                            nextBullet = 0;
                        }
                    }
                }

                // if the invader has touched either the left or right side of the screen and if it has we set bumped to true
                if (invaders[i].getX() > screenX - invaders[i].getLength() ||
                        invaders[i].getX() < 0) {

                    bumped = true;

                }
            }

        } // Update all the visible invaders

        // Did an invader bump into the edge of the screen
        if (bumped) {

            // Move all the invaders down and change direction
            for (int i = 0; i < numInvaders; i++) {
                invaders[i].dropDownAndReverse();
                // Have the invaders landed
                if (invaders[i].getY() > screenY - screenY / 10) {
                    lost = true;
                }
            }

            // Increase the menace level
            // By making the sounds more frequent
            menaceInterval = menaceInterval - 80;
        }

        //???
        // Update all the invaders bullets if active SM 1/3/22
        for (int i = 0; i < invadersBullets.length; i++) {
            if (invadersBullets[i].getStatus()) {
                invadersBullets[i].update(fps);
            }
        }

        if (lost) {
            initLevel();
        }

        // Update the players bullet
        if (bullet.getStatus()) {
            bullet.update(fps);
        }

        // Has the player's bullet hit the top of the screen
        if(bullet.getImpactPointY() < 0){
            bullet.setInactive();
        }

        // Has an invaders bullet hit the bottom of the screen
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getImpactPointY() > screenY){
                invadersBullets[i].setInactive();
            }
        }

        // Has the player's bullet hit an invader
        // if the bullet is active and if it is we loop through each of the invaders. For each invader that is visible,
        // we use RectF.intersects to check for a collision with the player’s bullet.
        if(bullet.getStatus()) {
            for (int i = 0; i < numInvaders; i++) {
                if (invaders[i].getVisibility()) {
                    //When a collision is detected the invader is made invisible, we play an explosion sound,
                    // set the bullet to inactive and add ten to the score.
                    if (RectF.intersects(bullet.getRect(), invaders[i].getRect())) {
                        invaders[i].setInvisible();
                        soundPool.play(invaderExplodeID, 1, 1, 0, 0, 1);
                        bullet.setInactive();
                        score = score + 10;

                        // Has the player won
                        if(score == numInvaders * 10){
                            paused = true;
                            score = 0;
                            lives = 5;
                            initLevel();
                        }
                    }
                }
            }
        }

        // Has an invader bullet hit the spaceship
        // loop through active bullets in the invadersBullets array
        for(int i = 0; i < invadersBullets.length; i++){
            if(invadersBullets[i].getStatus()){
                //checks  if invadersBullets hit the spaceShip
                if(RectF.intersects(spaceShip.getRect(), invadersBullets[i].getRect())){
                    //If it has bullet set to inactive, a life is deducted, a sound played .
                    invadersBullets[i].setInactive();
                    lives --;
                    soundPool.play(playerExplodeID, 1, 1, 0, 0, 1);

                    // Is it game over? (if lost all  lives - restart the game by calling init level)
                    if(lives == 0){
                        paused = true;
                        lives = 5;
                        score = 0;
                        initLevel();

                    }
                }
            }
        }
    } //end of  gameView update() method


    //Draw the newly updated scene
    private void draw() {
        //  Make sure our drawing surface is valid or we crash
        if (myHolder.getSurface().isValid()) {
            // Lock the canvas ready to draw
            canvas = myHolder.lockCanvas();
            // Draw everything to the screen while lockCanvas()
            // background color
            canvas.drawColor(Color.argb(255, 26, 128, 182));

            // Choose the brush color for drawing
            paint.setColor(Color.argb(255, 255, 255, 255));

            // drww the background
            bitmapback = BitmapFactory.decodeResource(context.getResources(), R.drawable.background);
            bitmapback = Bitmap.createScaledBitmap(bitmapback, (int)(screenX), (int)(screenY), false);
            canvas.drawBitmap(bitmapback, 0, 0, paint);

            // SM Now draw the player spaceship
            canvas.drawBitmap(spaceShip.getBitmap(), spaceShip.getX(), spaceShip.getY(), paint);

            // SM draw the invaders
            for (int i = 0; i < numInvaders; i++)
                if (invaders[i].getVisibility()) {
                    if (uhOrOh)
                        canvas.drawBitmap(invaders[i].getBitmap(), invaders[i].getX(), invaders[i].getY(), paint);
                    else
                        canvas.drawBitmap(invaders[i].getBitmap2(), invaders[i].getX(), invaders[i].getY(), paint);
                }

            // Draw the players bullet if active
            if (bullet.getStatus()) {
                canvas.drawRect(bullet.getRect(), paint);
            }

            // Draw the invaders bullets - Update all the invader's bullets if active
            for (int i = 0; i < invadersBullets.length; i++) {
                if (invadersBullets[i].getStatus()) {
                    canvas.drawRect(invadersBullets[i].getRect(), paint);
                }
            }

            // Draw the score and remaining lives and Change the brush color to organge
            paint.setColor(Color.argb(255, 249, 129, 0));

            //test size of the score
            paint.setTextSize(50);
            canvas.drawText("Score: " + score + "   Lives: " + lives, 1600, 50, paint);

            // unlock once drawing is finished
            myHolder.unlockCanvasAndPost(canvas);
        }
    } // end of draw method


    // If SpaceGameActivity thread is  paused/stopped then shutdown our thread.
    public void pause() {
        playing = false;
        try {
            gameThread.join();
        } catch (InterruptedException e) {
            Log.e("Error:", "joining thread");
        }
    } //end of pause method

    // If SpaceGameActivity is started then start the thread.
    public void resume() {
        playing = true;
        gameThread = new Thread(this);
        gameThread.start();
    } //end of resume method

    // The SurfaceView class implements onTouchListener
    // we can override this method and detect screen touches.
    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {

        switch (motionEvent.getAction() & MotionEvent.ACTION_MASK) {

            // Player has touched the screen
            //ACTION_DOWN case we check if a touch occurs ABOVE the bottom half of the screen
            // if so we call shoot on bullet passing in the coordinates of the top centre of the player’s ship.
            // If shoot returns true then a bullet is launched and a sound  is played.
            case MotionEvent.ACTION_DOWN:

                paused = false;

                if (motionEvent.getY() > screenY - screenY / 2) {
                    if (motionEvent.getX() > screenX / 2) {
                        spaceShip.setMovementState(spaceShip.RIGHT);
                        //shooting
                        bullet.shoot(spaceShip.getX() + spaceShip.getLength(), spaceShip.getY() + spaceShip.getHeight() / 2, 2);
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                    } else {
                        spaceShip.setMovementState(spaceShip.LEFT);
                        bullet.shoot(spaceShip.getX(), spaceShip.getY() + spaceShip.getHeight() / 2, 3);
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                    }

                }

                if (motionEvent.getY() < screenY - screenY / 2) {
                    if (motionEvent.getX() > screenX / 2) {
                        spaceShip.setMovementState(spaceShip.UP);
                        bullet.shoot(spaceShip.getX() + spaceShip.getLength() / 2, spaceShip.getY(), 0);
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                    } else {
                        spaceShip.setMovementState(spaceShip.DOWN);
                        bullet.shoot(spaceShip.getX() + spaceShip.getLength() / 2, spaceShip.getY() + spaceShip.getHeight(), 1);
                        soundPool.play(shootID, 1, 1, 0, 0, 1);
                    }
                }
                break;

            // Player has removed finger from screen
            case MotionEvent.ACTION_UP:
                spaceShip.setMovementState(spaceShip.STOPPED);

                break;
        }
        return true;
    } //end onTouchEvent


    private void checkCollisions() {

        if (bullet.getImpactPointY() < 0)
            bullet.setInactive();
        if (bullet.getImpactPointY() > screenY)
            bullet.setInactive();

        if (bullet.getImpactPointX() < 0)
            bullet.setInactive();
        if (bullet.getImpactPointX() > screenX)
            bullet.setInactive();

    } //end of checkCollisions

} // end class SpaceGameView