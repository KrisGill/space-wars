package com.example.spaceinvaders;

import android.graphics.RectF;

public class Bullet {
    //x and y to hold the bullet’s location
    private float x;
    private float y;
    // RectF which will be used to both draw and detect collisions on a bullet
    private RectF rect;

    // Which way is it shooting -  control the direction of a bullet
    public int UP = 0;
    public int DOWN = 1;
    public int RIGHT = 2;
    public int LEFT = 3;

    // heading will hold one of the above values;  initially set to -1 because it is going nowhere at the moment
    int heading = -1;
    //This is the pixels per second that the bullet will travel (lower the spped faster the bullet)
    //    float speed = 650;
    float speed = 400;

    //bullet coordinates
    private int screenY;
    private int screenX;
    private int width;
    private int height;

    private boolean isActive;

    public Bullet(int screenY, int screenX) {

        height = screenY / 20;
        isActive = false;
        //initializes a blank RectF object.
        this.rect = new RectF();
        this.screenX =screenX;
        this.screenY = screenY;

    }


    //getImpactPointY method which returns the tip pixel of the bullet.
    // This will be different depending on whether the bullet is heading down (fired by an invader)
    // or up (fired up, down left or right the the player)
    public float getImpactPointX() {
        if (heading == RIGHT){
            return  x + width; }

        return x;}

    //getters and setters that pass rect back to SpaceGameView for collision detection and drawing
    public RectF getRect(){
        return  rect;
    }

    //eturns the status ( isActive true or false) which as we will see is useful for knowing when to
    // draw and check for collisions
    public boolean getStatus(){
        return isActive;
    }

    public void setInactive(){
        isActive = false;
    }

    public float getImpactPointY() {
        if (heading == DOWN) {
            return y + height;
        }

        return y;

    }

    public boolean shoot(float startX, float startY, int direction) {
        // set isActive to  true and false as needed so we know when to draw and update each bullet and
        // when we don’t need to bother.
        if (!isActive) {
        //   initialise  x and y locations
            x = startX;
            y = startY;
            //heading could be left right up or down
            heading = direction;
            //bullet is set to isActive = true
            isActive = true;
            // Bullet width and height is initialised right away to 2 pixels
            if ((direction == RIGHT)||(direction==LEFT))
            {  width = screenX/20;
                height = 2;}

            else{height = screenY/20;
                width = 2;}

            // Bullet already active
            return true;
        }

        // Bullet already active
        return false;
    }

    //bullet update method to update x and y in the usual way and also update rect so it is up-to-date for drawing and
    // collision detection when required.
    public void update(long fps) {

        //  move up or down right and left
        if(heading == UP){
            y = y - speed / fps;
        }else if (heading == DOWN){
            y = y + speed / fps;
        }
        else if (heading == RIGHT){
            x = x + speed / fps;
        }
        else
        { x = x - speed / fps;}

        // Update rect
        rect.left = x;
        rect.right = x + width;
        rect.top = y;
        rect.bottom = y + height;
    }
}

