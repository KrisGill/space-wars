package com.example.spaceinvaders;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Point;
import android.view.Display;

//Here we use Activity instead of  AppCompatActivity
// MainActivity is the entry point to the game.
// This will handle the game cycle by calling
// methods of spaceGameView when prompted to so by the OS.
public class MainActivity extends Activity {

    // spaceGameView is the view of the game
    // hold the logic of the game and respond to screen touches
    SpaceGameView spaceGameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get a display object to access screen details
        Display display = getWindowManager().getDefaultDisplay();

        // Load the resolution into a Point object
        Point size = new Point();
        display.getSize(size);

        // Initialise spaceGameView/gameView and set the view
        spaceGameView = new SpaceGameView(this, size.x, size.y);
        setContentView(spaceGameView);

    }

    // This method executes when the player starts the game
    @Override
    protected void onResume() {
        super.onResume();

        // Tell the gameView resume method to execute
        spaceGameView.resume();
    }

    // This method executes when the player quits the game
    @Override
    protected void onPause() {
        super.onPause();

        // Tell the gameView pause method to execute
        spaceGameView.pause();
    }
}
