package com.example.spaceinvaders;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.RectF;

import java.util.Random;

public class Invader {

    RectF rect;

    Random generator = new Random();

    // the player ship will be represented by a Bitmap
    private Bitmap bitmap1;
    private Bitmap bitmap2;

    // how long and high the paddle will be
    private float length;
    private float height;

    // x coordinate of the far left
    private float x;

    // y coordinate of the top
    private float y;

    private float shipSpeed;

    public final int LEFT = 1;
    public final int RIGHT = 2;

    private int shipMoving = RIGHT;

    boolean isVisible;

    //Invader constructor
    public Invader(Context context, int row, int column, int screenX, int screenY) {

        //initialise rect as a blank rectangle
        rect = new RectF();

        //initialise length and width based on the screen resolution
        length = screenX / 20;
        height = screenY / 20;

        // we want to see the invader unless it is shot
        isVisible = true;


        // padding- 50th of the screens x resolution to determine the invader’s exact starting location
        // (higher the value invaders are more compact - 25 would show more of a distance)
        int padding = screenX / 50;

        //x and y location on the screen is determined by the invader’s position in the invader army
        //A row and column number is passed into the constructor and this is used along with padding
        x = column * (length + padding);
        y = row * (length + padding / 4);

        // initialize the bitmap
        bitmap1 = BitmapFactory.decodeResource(context.getResources(), R.drawable.invader);
        bitmap2 = BitmapFactory.decodeResource(context.getResources(), R.drawable.invader2);

        // stretch the first bitmap to a size appropriate for the screen resolution
        bitmap1 = Bitmap.createScaledBitmap(bitmap1,
                (int)(length),
                (int)(height),
                false);

        // stretch the first bitmap to a size appropriate for the screen resolution
        bitmap2 = Bitmap.createScaledBitmap(bitmap2,
                (int)(length),
                (int)(height),
                false);

        //set the speed in pixels per second...
        shipSpeed = 40;
    }


    //getters, setters and helper methods.
    public void setInvisible() {

        isVisible = false;
    }

    public boolean getVisibility() {

        return isVisible;
    }

    public RectF getRect() {

        return rect;
    }
    // get the two bitmaps and return them to the code that called them
    public Bitmap getBitmap() {

        return bitmap1;
    }

    public Bitmap getBitmap2() {

        return bitmap2;
    }
    //getX  getY and getLength return the x,  y and length. These are used, as they were with spaceShip to get precise coordinates
    // at which to fire a bullet
    public float getX() {

        return x;
    }

    public float getY() {

        return y;
    }

    public float getLength() {

        return length;
    }
    //end of getters, setters and helper methods.

    public void update(long fps) {
        if (shipMoving == LEFT)
            x = x - shipSpeed / fps;
        if (shipMoving == RIGHT)
            x = x + shipSpeed / fps;

        // update rect which is used to detect hits
        rect.top = y;
        rect.bottom = y + height;
        rect.left = x;
        rect.right = x + length;
    } //end of invader class update()

    public void dropDownAndReverse() {
        if (shipMoving == LEFT)
            shipMoving = RIGHT;
        else
            shipMoving = LEFT;

        y = y + height;

        //speed is increased by 18%
        shipSpeed = shipSpeed * 1.18f;
    } //end dropDownAndReverse()

    public boolean takeAim(float playerShipX, float playerShipLength) {

        int randomNumber = -1;

        //  detects if the Invader object is approximately horizontally aligned with the player.
        if ((playerShipX + playerShipLength > x &&
                playerShipX + playerShipLength < x + length) || (playerShipX > x && playerShipX < x + length)) {

            // If it is a random number is generated to produce a 1 in 150 chance of returning true to the calling code
            randomNumber = generator.nextInt(150);
            if (randomNumber == 0) {
                //when true is returned an attempt to launch a bullet is made with a call to shoot
                return true;
            }
            return true;
        }

        // If firing randomly (not near the player) a 1 in 2
        //
        //
        // 000 chance
        randomNumber = generator.nextInt(2000);
        if (randomNumber == 0) {
            return true;
        }

        return false;
    }

}